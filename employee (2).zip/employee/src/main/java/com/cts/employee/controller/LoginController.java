package com.cts.employee.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.employee.model.Emp;
import com.cts.employee.service.LoginService;

@Controller
public class LoginController {
	@Autowired                             ///create object "service" at run time 
	private LoginService service;

	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String showLoginpage(@ModelAttribute("emp") Emp emp) {    //model attribute binds the form to emp 
	  
	return "login";     // directs to login.jsp page   at first i direct to the login.jsp page

	}


	@RequestMapping(value="/submitlogin", method=RequestMethod.POST)
	public String checkLoginDetails(@Valid@ModelAttribute("emp") Emp emp,BindingResult result) {    //model attribute binds the form to emp    //result of validation is at result and that result is used to check for errors here down below

	  
		if(result.hasErrors()) {
			//System.err.println(result.getErrorCount());
			return "login";    /// if there is any error ,it will direct to the login page again
		}
		  return "success";     ///if there isn't ,then it goes to success page
		 	 

	}
}
