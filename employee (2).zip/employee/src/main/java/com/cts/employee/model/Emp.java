package com.cts.employee.model;

import java.util.Date;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class Emp {
	public Emp(){}
	
	@NotBlank(message = "Name cannot be NULL")  //Used @NotBlank to make the name not empty
	private String empName;
	
	@DateTimeFormat(iso=ISO.DATE)    //ISO DATE FORMAT DD/MM/YYYY Here i used ISO date pattern so that we can get the valid date till now
	private Date doj;
	@Min(value=10, message = "Phone Number should be of 10 digits")  //used @Min to get the phone number with a minimum of 10 digits
	private Long phoneno;
	 @Email(message = "Email-Id should be a Valid one")  // Here also i used @Email for a valid emailid
	private String Email;
	 
	 
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(Long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	

}
